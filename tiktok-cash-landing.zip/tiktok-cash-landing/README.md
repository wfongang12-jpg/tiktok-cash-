# TikTok Cash by PDG — Page de vente

Page de vente statique (un seul fichier HTML + images), hébergée actuellement sur Netlify :
https://jovial-rolypoly-eff8a8.netlify.app

## Contenu
- `index.html` : la page (HTML + CSS + JS inline, aucune dépendance à installer)
- `img/` : captures de preuves de paiement, témoignages et photos

## Points techniques
- **Paiement** : tous les boutons « Acheter » pointent vers le checkout Chariow
  `https://bdwgfagp.mychariow.shop/prd_ti5eh43s/checkout`
- **Meta Pixel** : ID `1587106563218320`, chargé dans le `<head>`.
  - `PageView` à chaque visite
  - `InitiateCheckout` (value 5900 XAF) au clic sur un lien Chariow
  - L'événement `Purchase` est envoyé par Chariow (pixel configuré dans Chariow → Settings → Pixels)
- **Compte à rebours** : constante `FIN_PROMO` dans le script en bas de page.
- **Vidéos YouTube** : chargées au clic (miniature + iframe) pour accélérer la page.

## Déployer
Glisser le dossier sur https://app.netlify.com/drop, ou connecter ce dépôt GitHub à Netlify / Vercel (aucune commande de build).
